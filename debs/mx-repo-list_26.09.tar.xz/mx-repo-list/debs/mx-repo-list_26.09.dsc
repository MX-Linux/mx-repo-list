-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (native)
Source: mx-repo-list
Binary: mx-repo-list
Architecture: all
Version: 26.09
Maintainer: Adrian <adrian@mxlinux.org>
Standards-Version: 4.5.1
Vcs-Git: git://github.com/MX-Linux/mx-repo-list
Build-Depends: debhelper-compat (= 13)
Package-List:
 mx-repo-list deb admin optional arch=all
Checksums-Sha1:
 6a8d7c1566320708e265da813ab4b605af6e55da 6288 mx-repo-list_26.09.tar.xz
Checksums-Sha256:
 35285050bb6eb1d6c0a1a4351d825524daac81dff2c8a207b901cc2a589d3430 6288 mx-repo-list_26.09.tar.xz
Files:
 f41962d22370e23accccedd86f03ecdf 6288 mx-repo-list_26.09.tar.xz

-----BEGIN PGP SIGNATURE-----

iQFHBAEBCgAxFiEE8ndToY6S45N+YzXncJOMeAZ57pgFAmqxqZUTHGFkcmlhbkBt
eGxpbnV4Lm9yZwAKCRBwk4x4BnnumDUwB/kB0AoLjF8sLapVu9SDiTfJd7PtJZw0
oCIIfD7slQSjPcnMjpIpQXc1TwJzrSXBOPZkrlX238XF/ECe7lmCUAlC6BpVqOyq
t30HuMaDikQF6cuEzIXiXYjKwWm0VXxKglKV9pGFn72M3+H4KCSrDRH1W4STO1jQ
ittFx4foyx+bPUt/ZX4UcVQHboMvaYRkdl53h0Lw9VsAG4asLO0vD6Pdafay1ASC
pjMXipQnuZ8PpvnKtGmC3uyk1X0QSW6vrNCrfqPPMphPlYUBoMT36ijbnn7bP/SK
oaOATwNZ7lIDdXieaGj91xtu4FfF+228YZrjGiI1x6TIW7yEDaZvlV1s
=7o/l
-----END PGP SIGNATURE-----
